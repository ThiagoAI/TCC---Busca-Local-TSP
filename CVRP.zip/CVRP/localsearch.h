#ifndef LOCALSEARCH_H_
#define LOCALSEARCH_H_

#include "point.h"

//Vizinhança de inserção e 2-opt
int local_search (point** points,int size,int capacity);


#endif
